import UIKit

var Blackhawks = Dictionary<Int, Player>()

class Player
{
    var name: String
    var number: Int
    var age: Double
    var heightFT: Int
    var heightIn: Int
    var birthMonth: Int
    var country: String
    
    init(name: String, number: Int, age: Double, heightFT: Int, heightIn: Int, birthMonth: Int, country: String) {
        self.name = name
        self.number = number
        self.age = age
        self.heightFT = heightFT
        self.heightIn = heightIn
        self.birthMonth = birthMonth
        self.country = country
    }
    
}
var player1 = Player(name: "H. Borgstrom", number: 13,age: 24 ,heightFT: 6,heightIn: 3,birthMonth: 8,country: "Finland")
var player2 = Player(name: "R.Carpenter", number: 22,age: 30 ,heightFT: 6,heightIn: 0,birthMonth: 1,country: "USA")
var player3 = Player(name: "K. Dach", number: 77,age: 20 ,heightFT: 6,heightIn: 4,birthMonth: 1,country: "Canada")


Blackhawks = [13:player1, 22:player2, 77:player3]

var ageSorted: Array<Double> = []
var ageArray: Array<Double> = []
for ages in Blackhawks {
    ageArray.append(ages.value.age)
}
ageSorted = ageArray.sorted()


var countrySorted: Array<String> = []
var countryArray: Array<String> = []
for countries in Blackhawks {
    countryArray.append(countries.value.country)
}
countrySorted = countryArray.sorted()

var sumAge = 0.0
var averageAge = 0.0
for x in Blackhawks{
    sumAge += x.value.age
}
averageAge = sumAge / Double(Blackhawks.count)


var sumHeight = 0.00
var averageHeight = 0.00
for y in Blackhawks{
    sumHeight += Double((y.value.heightFT * 12) + (y.value.heightIn))
}
averageHeight = (sumHeight / Double(Blackhawks.count)) / 12

var occ1 = 0, occ2=0, occ3=0, occ4=0, occ5=0, occ6=0, occ7=0, occ8=0, occ9=0, occ10=0, occ11=0, occ12 = 0
for z in Blackhawks{
    if z.value.birthMonth == 1 {
        occ1+=1
    }
    if z.value.birthMonth == 2 {
        occ2+=1
    }
    if z.value.birthMonth == 3 {
        occ3+=1
    }
    if z.value.birthMonth == 4 {
        occ4+=1
    }
    if z.value.birthMonth == 5 {
        occ5+=1
    }
    if z.value.birthMonth == 6 {
        occ6+=1
    }
    if z.value.birthMonth == 7 {
        occ7+=1
    }
    if z.value.birthMonth == 8 {
        occ8+=1
    }
    if z.value.birthMonth == 9 {
        occ9+=1
    }
    if z.value.birthMonth == 10 {
        occ10+=1
    }
    if z.value.birthMonth == 11 {
        occ11+=1
    }
    if z.value.birthMonth == 12 {
        occ12+=1
    }
}
var months = Dictionary<Int, Int>()
var maxOcc = 0
var maxMonth = 0
months = [1:occ1,2:occ2,3:occ3,4:occ4,5:occ5,6:occ6,7:occ7,8:occ8,9:occ9,10:occ10,11:occ11,12:occ12]

for month in months{
    if maxOcc < month.value{
        maxOcc = month.value
        maxMonth = month.key
    }
}

